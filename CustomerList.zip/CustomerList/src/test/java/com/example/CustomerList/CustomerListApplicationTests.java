package com.example.CustomerList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerListApplicationTests {

	@Test
	void contextLoads() {
	}

}
