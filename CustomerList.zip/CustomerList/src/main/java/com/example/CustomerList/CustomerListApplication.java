package com.example.CustomerList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerListApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerListApplication.class, args);
	}

}
